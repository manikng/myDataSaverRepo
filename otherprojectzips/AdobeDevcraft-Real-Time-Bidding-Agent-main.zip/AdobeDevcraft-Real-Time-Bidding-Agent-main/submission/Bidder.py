from BidRequest import BidRequest

class Bidder():

    def getBidPrice(self, bidRequest: BidRequest) -> int:
        pass