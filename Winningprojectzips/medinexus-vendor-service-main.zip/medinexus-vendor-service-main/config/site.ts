export const siteConfig = {
    name: "MedInventory",
    description: "Medical Inventory Management System",
  }
  
  